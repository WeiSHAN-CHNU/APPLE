from ultralytics import YOLO
model = YOLO('D:/ultralytics-main/ultralytics-main/ultralytics/cfg/models/v8/yolov8-c2f-faster-ema.yaml')
# pass any model type
results = model.train(data='D:/ultralytics-main/ultralytics-main/data.yaml',epochs=300,project='run/train',name='exp')